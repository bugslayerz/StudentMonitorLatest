﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace StudentMonitor.Controllers
{
    public class StudentDetailsController : Controller
    {
        
        //public ActionResult ViewStudent(STUDENT objstudent)
        //{
        //    using (StudentEntities4 student = new StudentEntities4())
        //    {
        //        string userName = Convert.ToString(Session["UserName"]);
        //        liStudent = student.STUDENTS.Where(a => a.EMAIL.Equals(userName)).ToList();

        //    }
        //}
          
    }


}
